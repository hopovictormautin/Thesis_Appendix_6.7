#!/usr/bin/env python
# coding: utf-8

# In[6]:


import pandas as pd
import geopandas as gpd
#from shapely.geometry import Point, Polygon

shapefile = 'data/countries_110m/ne_110m_admin_0_countries.shp'
shapefile1 = 'data/ne_10m_admin_0_map_units/ne_10m_admin_0_map_units.shp'
datafile = 'S1_Dynamic_Europe_Central_Asia.csv'

gdf = gpd.read_file(shapefile)[['ADMIN', 'ADM0_A3', 'geometry']]
gdf1 = gpd.read_file(shapefile1)[['ADMIN', 'ADM0_A3', 'geometry']]
gdf.columns = ['country', 'country_code', 'geometry']
gdf1.columns = ['country', 'country_code', 'geometry']
print('head======')
gdf.head()

print('gdf.keys:', gdf.keys())
# In[7]:

print('==========')
print(list(gdf['country'])[0])
print(gdf[gdf['country'] == 'Antarctica'])
print(gdf1[gdf1['country'] == 'Hong Kong S.A.R.'])
hk_content = gdf1[gdf1['country'] == 'Hong Kong S.A.R.']
print('hk content:', hk_content['geometry'])
print('len:',len(list(gdf['country'])))
gdf.loc[177, 'country'] = 'Hong Kong S.A.R.'
gdf.loc[177, 'country_code'] = 'HKG'

print('geo me:',len(gdf1.loc[176, 'geometry']))
print('geo me:', gdf1.loc[176, 'country'])
#print('geo me:',gdf1.loc[177, 'geometry'].convex_hull)
print('geo me:',gdf.loc[0, 'geometry'])
#print('geo me1:',gdf.loc[len(list(gdf['geometry'])), 'geometry'])
#gdf.loc[177, 'geometry'] = None
gdf.loc[[177], 'geometry'] = gdf1.loc[[176], 'geometry'].values
#gdf.loc[177, 'geometry'] = gdf.loc[0, 'geometry']

#gdf[gdf['country'] == 'Hong Kong S.A.R.'] = gdf1[gdf1['country'] == 'Hong Kong S.A.R.']
print(list(gdf['country']))


#gdf = gdf.drop(gdf.index[159])


# In[8]:


#print(gdf[gdf['country'] == 'Antarctica'])
print(gdf[gdf['country'] == 'Hong Kong'])


# In[9]:


gdf.info()


# In[10]:


import pandas as pd

#datafile = 'S3-PartlyCoupledGDP.csv'

#datafile = 'S3-FixedREgeneration.csv'

datafile = 'S1_Dynamic_Europe_Central_Asia.csv'


df = pd.read_csv(datafile, names = ['entity', 'code', 'year', 'per_cent_obesity'], skiprows = 1)
print('df per_cent_ob:', df['per_cent_obesity'])
print('df per_cent_ob:', type(df['per_cent_obesity']))
print('df head:')
print('df head:', df.head())

def modify_obesity(x):
    print('modify:', x)
    print('type:', type(x))
    x = str(float(x.split('%')[0]) * 1)
    print(x)
    
    return x

df['per_cent_obesity'] = df['per_cent_obesity'].apply(modify_obesity) 
# In[11]:


df_2020 = df[df['year'] == 2020]

#Perform left merge to preserve every row in gdf.
merged = gdf.merge(df_2020, left_on = 'country_code', right_on = 'code', how = 'left')
print('merged:', merged)
#Replace NaN values to string 'No data'.
merged.fillna('No data', inplace = True)
 


# In[12]:


import json

#Read data to json
merged_json = json.loads(merged.to_json())

#Convert to str like object
json_data = json.dumps(merged_json)

#print(json_data)
# In[13]:


from bokeh.io import output_notebook, show, output_file
from bokeh.plotting import figure
from bokeh.models import GeoJSONDataSource, LinearColorMapper, ColorBar
from bokeh.palettes import brewer

#Input GeoJSON source that contains features for plotting.
geosource = GeoJSONDataSource(geojson = json_data)

#Define a sequential multi-hue color palette.
palette = brewer['YlGnBu'][8]

#Reverse color order so that dark blue is highest obesity.
palette = palette[::-1]

#Instantiate LinearColorMapper that linearly maps numbers in a range, into a sequence of colors.
color_mapper = LinearColorMapper(palette = palette, low = 0, high = 20)

#Define custom tick labels for color bar.
#tick_labels = {'0': '0%', '5': '5%', '10':'10%', '15':'15%', '20':'20%', '25':'25%', '30':'30%','35':'35%', '40': '>40%'}

#tick_labels = {'0': '0%', '5': '5%', '10':'10%', '15':'15%', '20':'20%', '25':'25%', '30':'30%','35':'35%', '40': '40%', '45': '45%', '50':'50%', '55':'55%', '60':'60%', '65':'65%', '70':'70%','75':'75%', '80':'80%', '85':'85%', '90':'90%', '95':'95%','100': '>100%'}

#tick_labels = {'0': '0%', '0.05': '5%', '0.1':'10%', '0.15':'15%', '0.20':'20%', '0.25':'25%', '0.30':'30%','0.35':'35%', '0.40': '40%', '0.45': '45%', '0.50':'50%', '0.55':'55%', '0.60':'60%', '0.65':'65%', '0.70':'70%','0.75':'75%', '0.80':'80%', '0.85':'85%', '0.90':'90%', '0.95':'95%','1.0': '>100%'}
tick_labels = {'0.0': '0%', '0.05': '5%', '0.1':'10%', '0.15':'15%', '0.20':'20%', '0.25':'25%', '0.30':'30%','0.35':'35%', '0.40': '40%', '0.45': '45%', '0.50':'50%', '0.55':'55%', '0.60':'60%', '0.65':'65%', '0.70':'70%','0.75':'75%', '0.80':'80%', '1.0':'85%', '5.0':'90%', '10.0':'95%','20.0': '>100%'}
#Create color bar. 
color_bar = ColorBar(color_mapper=color_mapper, label_standoff=8,width = 500, height = 20,
border_line_color=None,location = (0,0), orientation = 'horizontal', major_label_overrides = tick_labels)

#Create figure object.
p = figure(title = 'S1_Dynamic_Europe_Central_Asia, 2020', plot_height = 600 , plot_width = 950, toolbar_location = None)
p.xgrid.grid_line_color = None
p.ygrid.grid_line_color = None

#Add patch renderer to figure. 
p.patches('xs','ys', source = geosource,fill_color = {'field' :'per_cent_obesity', 'transform' : color_mapper},
          line_color = 'black', line_width = 0.25, fill_alpha = 1)

#Specify figure layout.
p.add_layout(color_bar, 'below')
print('enter ========')
#Display figure inline in Jupyter Notebook.
#output_notebook()

#Display figure.
show(p)


# In[14]:


from bokeh.io import curdoc, output_notebook
from bokeh.models import Slider, HoverTool
from bokeh.layouts import widgetbox, row, column

#Define function that returns json_data for year selected by user.
    
def json_data(selectedYear):
    yr = selectedYear
    df_yr = df[df['year'] == yr]
    merged = gdf.merge(df_yr, left_on = 'country_code', right_on = 'code', how = 'left')
    merged.fillna('No data', inplace = True)
    merged_json = json.loads(merged.to_json())
    json_data = json.dumps(merged_json)
    return json_data

#Input GeoJSON source that contains features for plotting.
geosource = GeoJSONDataSource(geojson = json_data(2020))

print('enter2 ========:', geosource)
#Define a sequential multi-hue color palette.
palette = brewer['YlGnBu'][8]

#Reverse color order so that dark blue is highest obesity.
palette = palette[::-1]

#Instantiate LinearColorMapper that linearly maps numbers in a range, into a sequence of colors. Input nan_color.
color_mapper = LinearColorMapper(palette = palette, low = 0, high = 20, nan_color = '#d9d9d9')

#Define custom tick labels for color bar.
#tick_labels = {'0': '0%', '5': '5%', '10':'10%', '15':'15%', '20':'20%', '25':'25%', '30':'30%','35':'35%', '40': '40%', '45': '45%', '50':'50%', '55':'55%', '60':'60%', '65':'65%', '70':'70%','75':'75%', '80':'80%', '85':'85%', '90':'90%', '95':'95%','100': '>100%'}
#tick_labels = {'0': '0%', '0.05': '5%', '0.1':'10%', '0.15':'15%', '0.20':'20%', '0.25':'25%', '0.30':'30%','0.35':'35%', '0.40': '40%', '0.45': '45%', '0.50':'50%', '0.55':'55%', '0.60':'60%', '0.65':'65%', '0.70':'70%','0.75':'75%', '0.80':'80%', '0.85':'85%', '0.90':'90%', '0.95':'95%','1.0': '>100%'}

tick_labels = {'0.0': '0%', '0.05': '5%', '0.1':'10%', '0.15':'15%', '0.20':'20%', '0.25':'25%', '0.30':'30%','0.35':'35%', '0.40': '40%', '0.45': '45%', '0.50':'50%', '0.55':'55%', '0.60':'60%', '0.65':'65%', '0.70':'70%','0.75':'75%', '0.80':'80%', '1.0':'85%', '5.0':'90%', '10.0':'95%','20.0': '>100%'}
#Add hover tool
hover = HoverTool(tooltips = [ ('Country/region','@country'),('% Predicted Value', '@per_cent_obesity')])


#Create color bar. 
color_bar = ColorBar(color_mapper=color_mapper, label_standoff=8,width = 500, height = 20,
                     border_line_color=None,location = (0,0), orientation = 'horizontal', major_label_overrides = tick_labels)


#Create figure object.
p = figure(title = 'S1_Dynamic_Europe_Central_Asia, 2020', plot_height = 600 , plot_width = 950, toolbar_location = None, tools = [hover])
p.xgrid.grid_line_color = None
p.ygrid.grid_line_color = None

#Add patch renderer to figure. 
p.patches('xs','ys', source = geosource,fill_color = {'field' :'per_cent_obesity', 'transform' : color_mapper},
          line_color = 'black', line_width = 0.25, fill_alpha = 1)


p.add_layout(color_bar, 'below')

# Define the callback function: update_plot
def update_plot(attr, old, new):
    yr = slider.value
    new_data = json_data(yr)
    geosource.geojson = new_data
    p.title.text = 'S1_Dynamic_Europe_Central_Asia, %d' %yr
    
# Make a slider object: slider 
slider = Slider(title = 'Year',start = 2020, end = 2050, step = 10, value = 2020)
slider.on_change('value', update_plot)

print('enter3 ========:', geosource)
# Make a column layout of widgetbox(slider) and plot, and add it to the current document
layout = column(p,widgetbox(slider))
curdoc().add_root(layout)

#Display plot inline in Jupyter notebook
#output_notebook()

#Display plot
show(layout)

print('enter4 ========:')

# In[ ]:




